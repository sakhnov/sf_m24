<?php
class Model
{
    public $string;
    public function __construct() {
        $this->string = "MVC + PHP = Awesome!";
    }

    public function get_data() {
        
    }
}